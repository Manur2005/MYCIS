<div class="jumbotron text-center" style="margin-bottom:0">
  <p>
    Sitio diseñado por: 
    <br>Manuela Montoya,
    Isabel Rodriguez,
    Yenifer Varelas,
    Sheila Erazo,
    Cristian Valencia,
    Sebastian Rodriguez.

  <br>Colombia, Medellín 2022.</br>
  </p>
</div>