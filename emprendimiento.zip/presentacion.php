
<div class="jumbotron text-center" style="margin-bottom:0">
  <h1>Endulza tu paladar con nosotros</h1>
  <p>Welcome</p> 
   <img src="img/oblea.jpg" alt="Oblea" width="400" height="400">
</div>

