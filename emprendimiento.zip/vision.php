<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<? //include 'presentacion.php'?>

<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>Historia de empresa:</h2>
      
  <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Conoce nuestra historia.</h2>
      
      <p> Contenido historia de la empresa. 
</p>
      <br>
      <p>Nuestra visión u objetivo es llegar a graduarnos y seguir con nuestro negocio, en un local brindando satisfación y alegría a la vida de las personas. También brindandoles productos de buena calidad y esquicitos. Y que se vayan siempre con una gran sonrisa. </p>
    </div>
  </div>
</div>
  
<?include 'footer.php'?>

</body>
</html>
