<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<? //include 'presentacion.php'?>

<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2> Historia de la empresa:</h2>
      
  <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Conoce nuestra historia.</h2>
    
      <p> Contenido historia.
</p>
      <br>
      
      <p>Nosotras queriamos crear un emprendimiento, pero no lo pudimos realizar por razones economicas, este año (2022) tambien teniamos la idea de vender algo y en eso el profesor Alberto nos dijo que ibamos a realizar  un emprendimiento con el apoyo de la fundación Loyola  nos pusimos muy contentas y empezamos a pensar en que vender y tuvimos la idea de endulzarle el paladar a las personas y así nació este hermoso proyecto. </p>
    </div>
  </div>
</div>

<?include 'footer.php'?>

</body>
</html>
