<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<? //include 'presentacion.php'?>

<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>Justificación de empresa:</h2>
      
  <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Nuestros productos</h2>
     
      <p> Contenidos de mis productos.
</p>
      <br>
      <h2>MYCIS</h2>
      
      <p>Vamos a realizar este negocio, ya que es una gran ayuda para nosotros mismos a fín de año para nuestra graduación y quedar con una pequeña base para ayudarnos, con el nuevo año que comienza. Ya sea para negocio o empezar nuestras carreras. </p>
    </div>
  </div>
</div>
  
<?include 'footer.php'?>

</body>
</html>
