<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<? //include 'presentacion.php'?>

<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>Productos de nuestra  Empresa</h2>
      
  <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Nuestros productos.</h2>
      <p> Contenidos de mis productos.
</p>
      <br>
      <h2>Delicias de la empresa</h2>
  
      <p>Nuestros producto son:
        <UL>
<li>Obleas.</li>
        <li>Solteritas.</li>
        <li>Vaso de crema con fresas.</li>
        </UL>
    </div>
  </div>
</div>

  <?include 'footer.php'?>

</body>
</html>
