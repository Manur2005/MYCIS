<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<? //include 'presentacion.php'?>

<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>Filosofía</h2>
      
  <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Filosofía</h2>
      
      <p> Contenido de la Filosofía
</p>
      <br>
      <p> Nuestra filosofía es atender a nuestros clientes con amor, amabilidad y respeto y que se sientan los mas comodos posibles mientras estan en nuestro negocio, que sientan paz y tranquilidad para que puedan disfrutar nuestros deliciosos productos, queremos hacerlos felices aquel dia que nos visiten.  </p>
    </div>
  </div>
</div>
  
<?include 'footer.php'?>

</body>
</html>
