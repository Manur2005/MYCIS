<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<? //include 'presentacion.php'?>

<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>Misión:</h2>
      
  <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Misión</h2>
      
      <p> Contenido de nuestra misión.
</p>
      <br>
      <p>Nuestra misión como empresa consiste en satisfacer los antojos de los clientes con nuestros ricos productos y recoger fondos para facilitar la compra de todo lo necesario para nuestra graduación de cada miembro de nuestro grupo con el fin de ayudar a nuestras familias. </p>
    </div>
  </div>
</div>
<?include 'footer.php'?>
</body>
</html>
